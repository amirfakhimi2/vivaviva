from flask_nav import Nav

nav = Nav()