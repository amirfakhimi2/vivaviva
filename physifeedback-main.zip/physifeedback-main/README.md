# Physifeedback

See live demo at https://physifeedback.herokuapp.com.

To run, clone repository. Ensure flask and all its preconditions are installed. Deploy using `flask run`.
